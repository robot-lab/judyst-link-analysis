# class DuplicaterHeader(DocumentHeader)-------------------------
class DuplicateHeader(DocumentHeader): # needs some work

    """
    Subclass of DocumentHeader. Implements storage of data
    about document whose identifier is not unique.

    :attribute doc_id: str.
        Common ID of duplicated documents.
    :attribute header_list: list.
        List with instances of class Header.
        Any of them stores data about one of the duplicated documents.

    :method append: instancemethod.
        Append instance of class Header that contains data
        about duplicated document at self.header_list.
    :method convert_to_dict: instancemethod.
        Convert instance to dict object.
    :method convert_from_dict: staticmethod.
        Convert dict object to instance of own class.
        Called from superclass by iterface method with same name.
    """

    def __init__(self, docID, supertype=None, docType=None, title=None, releaseDate=None,
                 textSourceUrl=None, textLocation=None):
        """
        Constructor with optinal arguments. You must specify either
        argument 'docID' only to create empty list that ready to append
        new elements or all arguments except optional 'textLocation' to create
        list with first element.

        :param docID: str.
            Common ID of duplicated documents.
        :param supertype: str.
            Supertype of first duplicated document that be added at list.
        :param docType: str.
            Type of first duplicated document that be added at list.
        :param title: str.
            Title of first duplicated document that be added at list.
        :param releaseDate: datetime.date.
            Release date of first duplicated document that be added at list.
        :param textSourceUrl: str.
            URL of text source of first duplicated document that be added at list.
        :param textLocation: str, optional (default=None).
            Text location of first duplicated document that be added at list.
        """
        if isinstance(docID, str):
            super().__init__(docID)
        else:
            raise TypeError(f"'docID' must be instance of {str}")
        if isinstance(supertype, str) or supertype is None:
            self.supertype = supertype
        else:
            raise TypeError(f"'supertype' must be instance of {str}")
        if isinstance(docType, str) or docType is None:
            self.doc_type = docType
        else:
            raise TypeError(f"'docType' must be instance of {str}")
        if isinstance(title, str) or title is None:
            self.title = title
        else:
            raise TypeError(f"'title' must be instance of {str}")
        if isinstance(releaseDate, datetime.date) or releaseDate is None:
            self.release_date = releaseDate
        else:
            raise TypeError(f"'release_date' must be instance of {datetime.date}")
        if isinstance(textSourceUrl, str) or textSourceUrl is None:
            self.text_source_url = textSourceUrl
        else:
            raise TypeError(f"'textSourceUrl' must be instance of {str}")
        if isinstance(textLocation, str) or textLocation is None:
            self.text_location = textLocation
        else:
            raise TypeError(f"'textLocation' must be instance of {str}")

        if (supertype is None and docType is None and title is None and
            releaseDate is None and textSourceUrl is None and
                textLocation is None):
            self.header_list = []
        elif (supertype is not None and docType is not None and
              title is not None and releaseDate is not None and
                textSourceUrl is not None):
            self.header_list = [Header(docID, supertype, docType, title,
                                releaseDate, textSourceUrl, textLocation)]
        else:
            raise ValueError("You must specify either argument 'docID' only or"
                             " all arguments except optional 'textLocation'")

    def __eq__(self, other):
        if not isinstance(other, type(self)):
            raise TypeError(f"Compared objects must be of the same type:"
                            f"{type(self)} or {type(other)}")
        return (super().__eq__(other) and
                (collections.Counter(self.header_list) ==
                collections.Counter(other.header_list)))

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return super().__hash__()

    def append(self, supertype, docType, title, releaseDate, textSourceUrl,
               textLocation=None):
        """
        Append instance of class Header that contains data
        about duplicated document at self.header_list.

        :param supertype: str.
            Supertype of document that be added at list.
        :param docType: str.
            Type of document that be added at list.
        :param title: str.
            Title of document that be added at list.
        :param releaseDate: datetime.date.
            Release date of document that be added at list.
        :param textSourceUrl: str.
            URL of text source of document that be added at list.
        :param textLocation: str, optional (default=None).
            Text location of document that be added at list.
        """
        if isinstance(supertype, str) or supertype is None:
            self.supertype = supertype
        else:
            raise TypeError(f"'supertype' must be instance of {str}")
        if isinstance(docType, str) or docType is None:
            self.doc_type = docType
        else:
            raise TypeError(f"'docType' must be instance of {str}")
        if isinstance(title, str) or title is None:
            self.title = title
        else:
            raise TypeError(f"'title' must be instance of {str}")
        if isinstance(releaseDate, datetime.date) or releaseDate is None:
            self.release_date = releaseDate
        else:
            raise TypeError(f"'releaseDate' must be instance of {datetime.date}")
        if isinstance(textSourceUrl, str) or textSourceUrl is None:
            self.text_source_url = textSourceUrl
        else:
            raise TypeError(f"'textSourceUrl' must be instance of {str}")
        if isinstance(textLocation, str) or textLocation is None:
            self.text_location = textLocation
        else:
            raise TypeError(f"'textLocation' must be instance of {str}")

        h = Header(self.doc_id, supertype, docType, title, releaseDate, textSourceUrl,
                   textLocation)
        if h not in self.header_list:
            self.header_list.append(h)

    def convert_to_dict(self):
        """
        Convert instance to dict object that stores all values of attributes of instance.

        :return: dict.
            Dict object that stores values of attributes of instance.
        """
        dhList = []
        for dupHeader in self.header_list:
            dh = {
                'supertype': dupHeader.supertype,
                'doc_type':  dupHeader.doc_type,
                'title':  dupHeader.title,
                'release_date':  dupHeader.release_date.strftime('%d.%m.%Y'),
                'text_source_url':  dupHeader.text_source_url
                }
            if dupHeader.text_location is not None:
                dh['text_location'] = dupHeader.text_location
            dhList.append(dh)
        return ('not unique', dhList)

    @staticmethod
    def convert_from_dict(key: str, oldFormatHeader: dict):
        """
        Convert dict object to instance of own class.
        Called from superclass by iterface method with same name.

        :param key: str.
            Key which related with oldFormatHeader.
        :param oldFormatHeader: dict.
            Dict object that stores data about document.

        :return: DuplicateHeader.
            Instance of own class.
        """
        if not isinstance(key, str):
            raise TypeError(f"'key' mus be instance of {str}")
        if (not isinstance(oldFormatHeader, dict) and not isinstance(oldFormatHeader, tuple) and
                not isinstance(oldFormatHeader, list)):
            raise TypeError(f"'oldFormatHeader' must be instance of {dict} or {tuple} or {list}")
        docID = key
        duplicateHeader = DuplicateHeader(docID)
        try:
            for dh in oldFormatHeader[1]:
                supertype = dh['supertype']
                docType = dh['doc_type']
                title = dh['title']
                releaseDate = dateutil.parser.parse(dh['release_date'],
                                             dayfirst=True).date()
                textSourceUrl = dh['text_source_url']
                if 'text_location' in dh:
                    textLocation = dh['text_location']
                else:
                    textLocation = None
                duplicateHeader.append(supertype, docType, title, releaseDate,
                                       textSourceUrl, textLocation)
        except KeyError:
            raise KeyError(
                "'supertype', 'doc_type', 'title', 'release_date', "
                "'text_source_url' is required, only 'text_location' "
                "is optional")
        return duplicateHeader

# work with files in api_module: 
# def collect_headers(pathToFileForSave, pagesNum=None):
#     headersOld = ksrf.get_decision_headers(pagesNum)
#     headersNew = converters.convert_to_class_format(headersOld, models.DocumentHeader)
#     converters.save_pickle(headersNew, pathToFileForSave)
#     return headersNew


# def check_text_location_for_headers(headers, folder):
#     '''
#     Find files of the documents of the given headers
#    and add path to file in Header.text_location if file was found
#     '''
#     for key in headers:
#         # generate a possible path according to previously established rules
#         pathToTextLocation = ksrf.get_possible_text_location(
#             key, folder, ext='txt')
#         # if path is exist put it to header
#         if (os.path.exists(pathToTextLocation)):
#             headers[key].text_location = pathToTextLocation


# def download_texts_for_headers(headers, folder=DECISIONS_FOLDER_NAME):
#     for key in headers:
#         if (isinstance(headers[key], models.Header) and
#             (headers[key].text_location is None or
#                 not os.path.exists(headers[key].text_location))):
#             oldFormatHeader = headers[key].convert_to_dict()
#             ksrf.download_all_texts({key: oldFormatHeader}, folder)

old api:
def process_period(
        firstDateOfDocsForProcessing=None, lastDateOfDocsForProcessing=None,
        supertypesForProcessing=None,
        docTypesForProcessing=None,
        firstDateForNodes=None, lastDateForNodes=None,
        nodesIndegreeRange=None, nodesOutdegreeRange=None, nodesTypes=None,
        includeIsolatedNodes=True,
        firstDateFrom=None, lastDateFrom=None, docTypesFrom=None,
        supertypesFrom=None,
        firstDateTo=None, lastDateTo=None, docTypesTo=None,
        supertypesTo=None,
        weightsRange=None,
        graphOutputFilePath=PATH_TO_JSON_GRAPH, showPicture=True,
        takeHeadersFromLocalStorage=True,
        sendRequestToUpdatingHeadersInBaseFromSite=False,
        whichSupertypeUpdateFromSite=None):
    '''
    Process decisions from the date specified as firstDate to
    the date specified as lastDate.
    Write a graph of result of the processing and, if it was specified,
    draw graph and show it to user.
    '''
    if isinstance(firstDateOfDocsForProcessing, str):
        firstDateOfDocsForProcessing = dateutil.parser.parse(
            firstDateOfDocsForProcessing, dayfirst=True).date()
    if isinstance(lastDateOfDocsForProcessing, str):
        lastDateOfDocsForProcessing = dateutil.parser.parse(
            lastDateOfDocsForProcessing, dayfirst=True).date()
    if (firstDateOfDocsForProcessing is not None and
        lastDateOfDocsForProcessing is not None and
            firstDateOfDocsForProcessing > lastDateOfDocsForProcessing):
        raise ValueError("date error: The first date is later"
                         "than the last date.")

    if isinstance(firstDateForNodes, str):
        firstDateForNodes = dateutil.parser.parse(
            firstDateForNodes, dayfirst=True).date()
    if isinstance(lastDateForNodes, str):
        lastDateForNodes = dateutil.parser.parse(
            lastDateForNodes, dayfirst=True).date()
    if (firstDateForNodes is not None and
        lastDateForNodes is not None and
            firstDateForNodes > lastDateForNodes):
        raise ValueError("date error: The first date is later"
                         "than the last date.")

    if isinstance(firstDateFrom, str):
        firstDateFrom = dateutil.parser.parse(
            firstDateFrom, dayfirst=True).date()
    if isinstance(lastDateFrom, str):
        lastDateFrom = dateutil.parser.parse(
            lastDateFrom, dayfirst=True).date()
    if (firstDateFrom is not None and
        lastDateFrom is not None and
            firstDateFrom > lastDateFrom):
        raise ValueError(
            "date error: The first date is later than the last date.")

    if isinstance(firstDateTo, str):
        firstDateTo = dateutil.parser.parse(
            firstDateTo, dayfirst=True).date()
    if isinstance(lastDateTo, str):
        lastDateTo = dateutil.parser.parse(
            lastDateTo, dayfirst=True).date()
    if (firstDateTo is not None and
        lastDateTo is not None and
            firstDateTo > lastDateTo):
        raise ValueError(
            "date error: The first date is later than the last date.")

    if takeHeadersFromLocalStorage:
        jsonHeaders = converters.load_json(PATH_TO_JSON_HEADERS)
    else:
        #TODO: using param 'whichSupertypeReloadFromSite' isn't implemented
        jsonHeaders = wc_interface.get_all_headers(
            sendRequestToUpdatingHeadersInBaseFromSite,
            whichSupertypeUpdateFromSite)
        converters.save_json(jsonHeaders, PATH_TO_JSON_HEADERS)

    if not jsonHeaders:
        raise ValueError("Where's the document headers, Lebowski?")

    decisionsHeaders = converters.convert_to_class_format(
        jsonHeaders, models.DocumentHeader)

    #Not using, just backup. Maybe delete later
    converters.save_pickle(decisionsHeaders, PATH_TO_PICKLE_HEADERS)

    hFilter = models.HeadersFilter(
        supertypesForProcessing,
        docTypesForProcessing,
        firstDateOfDocsForProcessing, lastDateOfDocsForProcessing)

    # filtered headers to processing
    usingHeaders = hFilter.get_filtered_headers(decisionsHeaders)

    roughLinksDict = \
        rough_analysis.get_rough_links_for_docs(usingHeaders)

    response = final_analysis.get_clean_links(roughLinksDict, decisionsHeaders)
    links, rejectedLinks = response[0], response[1]

    if MY_DEBUG:
        converters.save_pickle(links, os.path.join(RESULTS_FOLDER_NAME,
                                                   'сleanLinks.pickle'))
        converters.save_pickle(rejectedLinks, os.path.join(
            RESULTS_FOLDER_NAME, 'rejectedLinks.pickle'))
        jsonLinks = \
            converters.convert_dict_list_cls_to_json_serializable_format(links)
        converters.save_json(jsonLinks, os.path.join(
            RESULTS_FOLDER_NAME, 'cleanLinks.json'))

    # got link graph
    linkGraph = final_analysis.get_link_graph(links)

    if MY_DEBUG:
        converters.save_pickle(linkGraph, PATH_TO_PICKLE_GRAPH)

    nFilter = models.GraphNodesFilter(
        nodesTypes,
        firstDateForNodes, lastDateForNodes,
        nodesIndegreeRange, nodesOutdegreeRange)
    hFromFilter = models.HeadersFilter(
        supertypesFrom,
        docTypesFrom,
        firstDateFrom, lastDateFrom)
    hToFilter = models.HeadersFilter(
        supertypesTo,
        docTypesTo,
        firstDateTo, lastDateTo)
    eFilter = models.GraphEdgesFilter(hFromFilter, hToFilter, weightsRange)
    subgraph = linkGraph.get_subgraph(nFilter, eFilter, includeIsolatedNodes)

    if MY_DEBUG:
        converters.save_pickle(subgraph, PATH_TO_PICKLE_SUBGRAPH)

    linkGraphLists = (subgraph.get_nodes_as_IDs_list(),
                      subgraph.get_edges_as_list_of_tuples())

    converters.save_json(linkGraphLists, graphOutputFilePath)

    if showPicture:
        visualizer.visualize_link_graph(linkGraphLists, 20, 1, (40, 40))
    return jsonLinks

def start_process_with(
        decisionID, depth,
        firstDateForNodes=None, lastDateForNodes=None,
        nodesIndegreeRange=None, nodesOutdegreeRange=None, nodesTypes=None,
        includeIsolatedNodes=True,
        firstDateFrom=None, lastDateFrom=None, docTypesFrom=None,
        supertypesFrom=None,
        firstDateTo=None, lastDateTo=None, docTypesTo=None,
        supertypesTo=None,
        weightsRange=None,
        graphOutputFilePath=PATH_TO_JSON_GRAPH, showPicture=True,
        takeHeadersFromLocalStorage=True,
        sendRequestToUpdatingHeadersInBaseFromSite=False,
        whichSupertypeUpdateFromSite=None,
        visualizerParameters=(20, 1, (40, 40))):
    '''
    Start processing decisions from the decision which uid was given and repeat
    this behavior recursively for given depth.
    '''
    if (depth < 0):
        raise "argument error: depth of the recursion must be large than 0."

    if isinstance(firstDateForNodes, str):
        firstDateForNodes = dateutil.parser.parse(
            firstDateForNodes, dayfirst=True).date()
    if isinstance(lastDateForNodes, str):
        lastDateForNodes = dateutil.parser.parse(
            lastDateForNodes, dayfirst=True).date()
    if (firstDateForNodes is not None and
        lastDateForNodes is not None and
            firstDateForNodes > lastDateForNodes):
        raise ValueError(
            "Date error: The first date is later than the last date.")

    if isinstance(firstDateFrom, str):
        firstDateFrom = dateutil.parser.parse(
            firstDateFrom, dayfirst=True).date()
    if isinstance(lastDateFrom, str):
        lastDateFrom = dateutil.parser.parse(
            lastDateFrom, dayfirst=True).date()
    if (firstDateFrom is not None and
        lastDateFrom is not None and
            firstDateFrom > lastDateFrom):
        raise ValueError(
            "date error: The first date is later than the last date.")

    if isinstance(firstDateTo, str):
        firstDateTo = dateutil.parser.parse(
            firstDateTo, dayfirst=True).date()
    if isinstance(lastDateTo, str):
        lastDateTo = dateutil.parser.parse(
            lastDateTo, dayfirst=True).date()
    if (firstDateTo is not None and
        lastDateTo is not None and
            firstDateTo > lastDateTo):
        raise ValueError(
            "date error: The first date is later than the last date.")

    if takeHeadersFromLocalStorage:
        jsonHeaders = converters.load_json(PATH_TO_JSON_HEADERS)
    else:
        #TODO: using param 'whichSupertypeReloadFromSite' is not implemented
        jsonHeaders = wc_interface.get_all_headers(
            sendRequestToUpdatingHeadersInBaseFromSite,
            whichSupertypeUpdateFromSite)
        converters.save_json(jsonHeaders, PATH_TO_JSON_HEADERS)

    if not jsonHeaders:
        raise ValueError(
            "Where's the document headers, Lebowski?")

    decisionsHeaders = \
        converters.convert_to_class_format(jsonHeaders, models.DocumentHeader)

    #Not using, just backup. Maybe delete later
    converters.save_pickle(decisionsHeaders, PATH_TO_PICKLE_HEADERS)

    if decisionID not in decisionsHeaders:
        raise ValueError("Unknown docID")

    toProcess = {decisionID: decisionsHeaders[decisionID]}
    processed = {}
    allLinks = {decisionsHeaders[decisionID]: []}
    while depth > 0 and len(toProcess) > 0:
        depth -= 1
        roughLinksDict = rough_analysis.get_rough_links_for_docs(
            toProcess)
        cleanLinks = final_analysis.get_clean_links(roughLinksDict,
                                                    decisionsHeaders)[0]
        allLinks.update(cleanLinks)
        processed.update(toProcess)
        toProcess = {}
        for decID in cleanLinks:
            for cl in cleanLinks[decID]:
                docID = cl.header_to.doc_id
                if (docID not in processed):
                    toProcess[docID] = decisionsHeaders[docID]

    linkGraph = final_analysis.get_link_graph(allLinks)
    if MY_DEBUG:
        converters.save_pickle(allLinks, os.path.join(
            RESULTS_FOLDER_NAME, 'processedWithсleanLinks.pickle'))
        jsonLinks = \
            converters.convert_dict_list_cls_to_json_serializable_format(
                allLinks)
        converters.save_json(jsonLinks, os.path.join(
            RESULTS_FOLDER_NAME, 'processedWithcleanLinks.json'))
        converters.save_pickle(linkGraph, os.path.join(
            RESULTS_FOLDER_NAME, 'processedlinkGraph.pickle'))

    nFilter = models.GraphNodesFilter(
        nodesTypes,
        firstDateForNodes, lastDateForNodes,
        nodesIndegreeRange, nodesOutdegreeRange)
    hFromFilter = models.HeadersFilter(
        supertypesFrom,
        docTypesFrom,
        firstDateFrom, lastDateFrom)
    hToFilter = models.HeadersFilter(
        supertypesTo,
        docTypesTo,
        firstDateTo, lastDateTo)
    eFilter = models.GraphEdgesFilter(hFromFilter, hToFilter, weightsRange)
    subgraph = linkGraph.get_subgraph(nFilter, eFilter, includeIsolatedNodes)
    if MY_DEBUG:
        converters.save_pickle(subgraph, 'processWithSubgraph.pickle')
    linkGraphLists = (subgraph.get_nodes_as_IDs_list(),
                      subgraph.get_edges_as_list_of_tuples())

    converters.save_json(linkGraphLists, graphOutputFilePath)
    if (showPicture):
        visualizer.visualize_link_graph(linkGraphLists,
                                        visualizerParameters[0],
                                        visualizerParameters[1],
                                        visualizerParameters[2])

# end of start_process_with---------------------------------------------

# rough analysis start ----------------
import re
from typing import Dict, List, Union, Type

if __package__:
    from link_analysis.models import Header, RoughLink, Positions
else:
    from models import Header, RoughLink, Positions
    import wc_interface

# link pattern main part
lpMP = (r".*?\sот[\s\d]+?(?:(?:января|февраля|марта|апреля|мая|июня|июля|"
        r"августа|сентября|октября|ноября|декабря)+?[\s\d]+?года|\d{2}\."
        r"\d{2}\.\d{4})[\s\d]+?(?:№|N)[\s\d]+?[-\w/]*.*?")
# link pattern prefix #1
lpPRF1 = r"(?<=\.\s)\s*?[А-ЯA-Z]"
# link pattern postfix #1
lpPSF1 = r"(?=\.\s[А-ЯA-Z])"
# link pattern prefix #2
lpPRF2 = r"(?<=^)\s*?[А-ЯA-Zа-яa-z]"
# link pattern postfix #2
lpPSF2 = r"(?=\.$)"
linkPattern = re.compile(f"""(?:{lpPRF1+lpMP+lpPSF1}|{lpPRF1+lpMP+lpPSF2}|
            {lpPRF2+lpMP+lpPSF1}|{lpPRF2+lpMP+lpPSF2})""", re.VERBOSE)

# pattern for removing of redundant leading sentences
reductionPattern = re.compile(
    r"(?:[А-ЯA-Z].*[^А-ЯA-Z]\.\s*(?=[А-ЯA-Z])|^[А-ЯA-Zа-яa-z]"
    r".*[^А-ЯA-Z]\.\s*(?=[А-ЯA-Z]))")

# other patterns
splitPattern = re.compile(r"""(?i)о(?=т[\s\d]+?(?:(?:января|февраля|марта|апреля|мая|июня|июля|
            августа|сентября|октября|ноября|декабря)+?[\s\d]+?года|\d{2}
            \.\d{2}\.\d{4})[\s\d]+?(?:№|N))""")
datePattern = re.compile(r"""(?i)т[\s\d]+?(?:(?:января|февраля|марта|апреля|мая|июня|июля|
            августа|сентября|октября|ноября|декабря)+?[\s\d]+?года|\d{2}
            \.\d{2}\.\d{4})(?=\s)""")
numberPattern = re.compile(r'(?:№|N)[\s\d]+[-\w/]*')
opinionPattern = re.compile(r'(?i)мнение\s+судьи\s+конституционного')


def get_rough_links(header: Header) -> Union[List[RoughLink], Type[TypeError], Type[FileNotFoundError]]:
    """
    :param header: instance of class models.Header
    """
    text = wc_interface.get_text(header.doc_id)
    if not text:
        print(f"fileID: {header.doc_id}")
        raise ValueError("Where's the text, Lebowski?")
    roughLinks = []
    opinion = opinionPattern.search(text)
    if opinion is not None:
        matchObjects = linkPattern.finditer(text, endpos=opinion.start())
    else:
        matchObjects = linkPattern.finditer(text)
    for match in matchObjects:
        linksForSplit = match[0]
        reduct = reductionPattern.search(linksForSplit)
        if reduct is not None:
            reductCorrection = reduct.end()
            #context = linksForSplit.replace(reduct[0], '') + '.'
        else:
            reductCorrection = 0
            #context = linksForSplit
        linkCorrection = len(splitPattern.split(linksForSplit,
                                        maxsplit=1)[0])
        contextStartPos = match.start(0) + reductCorrection
        contextEndPos = match.end(0) + 1
        linkStartPos = match.start(0) + linkCorrection 

        splitedLinksForDifferentYears = splitPattern.split(linksForSplit)[1:]
        for oneYearLinks in splitedLinksForDifferentYears:
            date = datePattern.search(oneYearLinks)[0]
            matchNumbers = list(numberPattern.finditer(oneYearLinks))

            linkEndPos = linkStartPos + matchNumbers[-1].end(0) + 1
            for number in matchNumbers:
                gottenRoughLink = 'о' + date + ' ' + number[0].upper()
                roughLinks.append(RoughLink(header, gottenRoughLink,
                                  Positions(contextStartPos, contextEndPos,
                                            linkStartPos, linkEndPos)))
            linkStartPos += len(oneYearLinks) + 1           
    return roughLinks


def get_rough_links_for_docs(
        headers: Dict[str, Header]) -> Dict[Header, List[RoughLink]]:
    """
    :param header: dict of instances of class models.Header
    return dict with list of instances of class RoughLink
    as element and instance class Header as key,
    also this dict may contain two lists of instances of
    lass models.Header which were unsuccessfully processed
    """
    result = {}  # type: Dict[Header, List[RoughLink]]
    for decisionID in headers:
        if not isinstance(headers[decisionID], Header):
            raise TypeError(f"Any element of 'headers' must be instance of {Header}")
        maybeRoughLinks = get_rough_links(headers[decisionID])
        result[headers[decisionID]] = maybeRoughLinks
    return result
# rough analysis end --------------------

# final analysis start -----------------
import re
from typing import Dict, Tuple, List, Union

if __package__:
    from link_analysis.models import Header, CleanLink,\
        Positions, LinkGraph, RoughLink
else:
    from models import Header, CleanLink, Positions, RoughLink
    from models import LinkGraph

yearPattern = re.compile(r'(?:(?<=\s)\d{4}(?=\s)|(?<=\d\d\.\d\d\.)\d{4}(?=\s))')
numberPattern = re.compile(r'\d+(-[А-ЯA-Zа-яa-z]+)+')
splitPattern = re.compile(r'(?:№|N)')


def get_clean_links(
        collectedLinks: Dict[Header, List[RoughLink]],
        courtSiteContent: Dict[str, Header],
        courtPrefix: str='КСРФ/') -> Tuple[Dict[Header, List[CleanLink]],
                                           Dict[Header, List[RoughLink]]]:
    '''
    Gets clean links.
    arguments:
    collected_links: a dictionary with list of instances of class Rough link
    as element and instance class Header as key.
    court_site_content: a dictionary with intance of class DocumentHeader
    as element and string with court decision ID (uid) as a key.
    '''
    rejectedLinks = {}  # type: Dict[Header, List[RoughLink]]
    checkedLinks = {}  # type: Dict[Header, List[CleanLink]]
    for headerFrom in collectedLinks:
        checkedLinks[headerFrom] = []
        for link in collectedLinks[headerFrom]:
            spam = clSplitPattern.split(link.body)
            number = clNumberPattern.search(spam[-1])
            years = clYearPattern.findall(spam[0])
            if years and number:
                eggs = False
                while years:
                    gottenID = (courtPrefix + number[0].upper() +
                                '/' + years.pop())
                    if gottenID in courtSiteContent:
                        eggs = True
                        years.clear()
                        headerTo = courtSiteContent[gottenID]
                        positionAndContext = link.positions
                        cleanLink = None
                        for cl in checkedLinks[headerFrom]:
                            if cl.header_to == headerTo:
                                cleanLink = cl
                                break
                        if cleanLink is not None:
                            cleanLink.citations_number += 1
                            cleanLink.append(positionAndContext)
                        else:
                            cleanLink = CleanLink(headerFrom, headerTo, 1,
                                                  positionAndContext)
                            checkedLinks[headerFrom].append(cleanLink)
                if not eggs:
                    if headerFrom not in rejectedLinks:
                        rejectedLinks[headerFrom] = []
                    rejectedLinks[headerFrom].append(link)
            else:
                if headerFrom not in rejectedLinks:
                    rejectedLinks[headerFrom] = []
                rejectedLinks[headerFrom].append(link)
    return (checkedLinks, rejectedLinks)


def get_link_graph(checkedLinks: Dict[Header, List[CleanLink]]) -> LinkGraph:
    '''
    Gets Link Graph, returning instance of clas LinkGraph
    argument: checked_links is a dictionary with list of instances
    of class CleanLink as element and string with court decision ID (uid)
    as a key.
    '''
    linkGraph = LinkGraph()
    for header in checkedLinks:
        linkGraph.add_node(header)
        for cl in checkedLinks[header]:
            linkGraph.add_node(cl.header_to)
            linkGraph.add_edge(cl)
    return linkGraph
#final analysis end ---------------
