def main():
    print("it's main")
main()
