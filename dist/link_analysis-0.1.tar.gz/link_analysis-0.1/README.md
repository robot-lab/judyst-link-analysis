# Judist link analysis.
Этот репозиторий посвящен компоненте анализа ссылок в юридических документах. Посетите [wiki](https://github.com/robot-lab/judyst-link-analysis/wiki) для получения большей информации. 
 ***
[Команда](https://github.com/robot-lab/judyst-main-web-service/wiki/Team-members)
 [Репозиторий проекта](https://github.com/robot-lab/judyst-main-web-service)
