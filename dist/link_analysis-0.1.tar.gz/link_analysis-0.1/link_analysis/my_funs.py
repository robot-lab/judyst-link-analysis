import converters
from web_crawler import ksrf
from api_module import DECISIONS_FOLDER_NAME, PATH_TO_PICKLE_HEADERS, RESULTS_FOLDER_NAME
import os
import models
import web_crawler
import re
import collections
from models import CleanLink, Header
from typing import Dict

def compare_clealinks(cl1: Dict[Header, CleanLink], cl2: Dict[Header, CleanLink]) -> bool:
    ncl1 = collections.Counter(cl1)
    ncl2 = collections.Counter(cl2)
    for key in ncl1:
        if key not in ncl2:
            print(f"{key.doc_id} not in ncl2")
            continue
        if ncl1[key] != ncl2[key]:
            print(f"{key.doc_id}: different numbers")
            a = set(ncl1[key])
            b = set(ncl2[key])
            ab = a-b
            ba = b-a
            print('please see difference')
    for key in ncl2:
        if key not in ncl1:
            print(f"{key.doc_id} not in ncl1")
            continue
    print('ok')


def get_only_unique_headers_to_list(pathToPickleHeaders=PATH_TO_PICKLE_HEADERS):
    allHeaders = converters.load_pickle(pathToPickleHeaders)
    uniqueHeaders = []
    for key in allHeaders:
        if isinstance(allHeaders[key], models.Header):
            uniqueHeaders.append(allHeaders[key])
    print(f"Number of unique Headers: {len(uniqueHeaders)}")
    converters.save_pickle(uniqueHeaders, 'TestResults\\unique_headers.pickle')
    uniqueHeadersJson = converters.convert_to_json_serializable_format(uniqueHeaders)
    converters.save_json(uniqueHeadersJson, 'TestResults\\unique_headers.json')
    fileList = os.listdir(DECISIONS_FOLDER_NAME)
    keysDownloadedFiles = []
    keysNotDownloadedFiles = []
    for filepath in fileList:
        filename = os.path.basename(filepath)
        if not filename.endswith('.txt'):
            continue
        keysDownloadedFiles.append(filename.replace('_', '/').replace('.txt', ''))
    for h in uniqueHeaders:
        if h.doc_id not in keysDownloadedFiles:
            keysNotDownloadedFiles.append(h.doc_id)
    print(keysNotDownloadedFiles)
    with open("TestResults\\notDownlodedFilesKeys.txt", 'wt', encoding='utf-8') as outfile:
        outfile.write('\n'.join(keysNotDownloadedFiles))

pageNumberPattern = re.compile(r"""(?:(?i)\x0c\s*\d+|\x0c(?=\s)|
                               (?i)\x0c\s*$)""", re.VERBOSE)
def del_NP_and_pageNums(textForProccessing):
    text = pageNumberPattern.sub('', textForProccessing)
    return text

def deleteNPinfiles(pathToFolder=DECISIONS_FOLDER_NAME):
    fileList = os.listdir(pathToFolder)
    i = 0
    lenf = len(fileList)
    for filepath in fileList:
        i+=1
        if filepath.endswith('.txt'):
            fileInput = open(DECISIONS_FOLDER_NAME + '\\' + filepath, 'rt', encoding='utf-8')
            fileTextForProcessing = fileInput.read()
            fileInput.close()
            text = del_NP_and_pageNums(fileTextForProcessing)
            with open(DECISIONS_FOLDER_NAME+ '\\' + filepath, 'wt', encoding='utf-8') as outfile:
                outfile.write(text)
            print(f"{filepath} update ({i}/{lenf})")
        else:
            continue

def get_only_unique_headers_to_dict(pathToPickleHeaders=PATH_TO_PICKLE_HEADERS):
    allHeaders = converters.load_pickle(pathToPickleHeaders)
    uniqueHeaders = {}
    for key in allHeaders:
        if isinstance(allHeaders[key], models.Header):
            uniqueHeaders[key] = allHeaders[key]
    converters.save_pickle(uniqueHeaders, 'TestResults\\unique_headers.pickle')
    jsonUH = converters.convert_to_json_serializable_format(uniqueHeaders)
    converters.save_json(jsonUH, 'TestResults\\unique_headers.json')
    print(f"Unique Headers Number: {len(uniqueHeaders)}")

def get_unnecessary_headers():
    uniqueHeaders = converters.load_pickle(DECISIONS_FOLDER_NAME + 'DecisionHeaders.pickle')
    uniqueHeadersIDs = []
    for h in uniqueHeaders:
        uniqueHeadersIDs.append(h.doc_id)
    keysDownloadedFiles = []
    fileList = os.listdir(DECISIONS_FOLDER_NAME)
    for filepath in fileList:
        filename = os.path.basename(filepath)
        if not filename.endswith('.txt'):
            continue
        keysDownloadedFiles.append(filename.replace('_', '/').replace('.txt', ''))
    unnecessaryFiles = []
    for key in keysDownloadedFiles:
        if key not in uniqueHeadersIDs:
            unnecessaryFiles.append(key)
    with open("TestResults\\unnecessaryFiles.txt", 'wt', encoding='utf-8') as outfile:
        outfile.write('\n'.join(unnecessaryFiles))


def my_collect_headers(pathToFileForSave, pagesNum=None):
    headersOld = ksrf.get_decision_headers(pagesNum)
    converters.save_json(headersOld, pathToFileForSave +'.json')
    headersNew = converters.convert_to_class_format(headersOld, models.DocumentHeader)
    converters.save_pickle(headersNew, pathToFileForSave + '.pickle')
    return headersNew


def saving_all_clean_links(num=None):
    cleanLinks = converters.load_pickle(os.path.join(RESULTS_FOLDER_NAME, 'сleanLinks.pickle'))
    cleanLinksLists = list(cleanLinks[key] for key in cleanLinks if cleanLinks[key])
    cleanLinksList = []
    summ = 0
    for L in cleanLinksLists:
        if not L:
            continue
        summ += len(L)
        cleanLinksList.extend(L)
        if num is not None and num < summ:
            break
    JSONcleanLinks = converters.convert_to_json_serializable_format(cleanLinksList)
    if num is None:
        converters.save_json(JSONcleanLinks, os.path.join(RESULTS_FOLDER_NAME, 'cleanLinks.json'))
    else:
        converters.save_json(JSONcleanLinks, os.path.join(RESULTS_FOLDER_NAME, '\\num_' + str(summ) +'_jsonCleanLinks.json'))


if __name__ == '__main__':
    class clsc():
        a = 1
        b = 'str'
        def __init__(self, a, c):
            self.a = a
            self.c = c
    i = clsc('xor', 'ccc')

    print("""sdasdasdasdadsasd
    1
    dasdasd
    2
    3
    adasd""")
    print('ok')