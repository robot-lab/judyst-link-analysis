import converters
from web_crawler import ksrf
from api_module import DECISIONS_FOLDER_NAME, PATH_TO_PICKLE_HEADERS, \
                       RESULTS_FOLDER_NAME
import os
import models
import web_crawler
import re
import collections
from models import CleanLink, Header
from typing import Dict
import json


def compare_clealinks(
        cl1: Dict[Header, CleanLink], cl2: Dict[Header, CleanLink]) -> bool:
    ncl1 = collections.Counter(cl1)
    ncl2 = collections.Counter(cl2)
    for key in ncl1:
        if key not in ncl2:
            print(f"{key.doc_id} not in ncl2")
            continue
        if ncl1[key] != ncl2[key]:
            print(f"{key.doc_id}: different numbers")
            a = set(ncl1[key])
            b = set(ncl2[key])
            ab = a-b
            ba = b-a
            print('please see difference')
    for key in ncl2:
        if key not in ncl1:
            print(f"{key.doc_id} not in ncl1")
            continue
    print('ok')


def get_only_unique_headers_to_list(pathToPickleHeaders=PATH_TO_PICKLE_HEADERS):
    allHeaders = converters.load_pickle(pathToPickleHeaders)
    uniqueHeaders = []
    for key in allHeaders:
        if isinstance(allHeaders[key], models.Header):
            uniqueHeaders.append(allHeaders[key])
    print(f"Number of unique Headers: {len(uniqueHeaders)}")
    converters.save_pickle(uniqueHeaders, 'TestResults\\unique_headers.pickle')
    uniqueHeadersJson = converters.convert_to_json_serializable_format(uniqueHeaders)
    converters.save_json(uniqueHeadersJson, 'TestResults\\unique_headers.json')
    fileList = os.listdir(DECISIONS_FOLDER_NAME)
    keysDownloadedFiles = []
    keysNotDownloadedFiles = []
    for filepath in fileList:
        filename = os.path.basename(filepath)
        if not filename.endswith('.txt'):
            continue
        keysDownloadedFiles.append(filename.replace('_', '/').replace('.txt', ''))
    for h in uniqueHeaders:
        if h.doc_id not in keysDownloadedFiles:
            keysNotDownloadedFiles.append(h.doc_id)
    print(keysNotDownloadedFiles)
    with open("TestResults\\notDownlodedFilesKeys.txt", 'wt', encoding='utf-8') as outfile:
        outfile.write('\n'.join(keysNotDownloadedFiles))

pageNumberPattern = re.compile(r"""(?:(?i)\x0c\s*\d+|\x0c(?=\s)|
                               (?i)\x0c\s*$)""", re.VERBOSE)
def del_NP_and_pageNums(textForProccessing):
    text = pageNumberPattern.sub('', textForProccessing)
    return text

def deleteNPinfiles(pathToFolder=DECISIONS_FOLDER_NAME):
    fileList = os.listdir(pathToFolder)
    i = 0
    lenf = len(fileList)
    for filepath in fileList:
        i+=1
        if filepath.endswith('.txt'):
            fileInput = open(DECISIONS_FOLDER_NAME + '\\' + filepath, 'rt', encoding='utf-8')
            fileTextForProcessing = fileInput.read()
            fileInput.close()
            text = del_NP_and_pageNums(fileTextForProcessing)
            with open(DECISIONS_FOLDER_NAME+ '\\' + filepath, 'wt', encoding='utf-8') as outfile:
                outfile.write(text)
            print(f"{filepath} update ({i}/{lenf})")
        else:
            continue

def get_only_unique_headers_to_dict(pathToPickleHeaders=PATH_TO_PICKLE_HEADERS):
    allHeaders = converters.load_pickle(pathToPickleHeaders)
    uniqueHeaders = {}
    for key in allHeaders:
        if isinstance(allHeaders[key], models.Header):
            uniqueHeaders[key] = allHeaders[key]
    converters.save_pickle(uniqueHeaders, 'TestResults\\unique_headers.pickle')
    jsonUH = converters.convert_to_json_serializable_format(uniqueHeaders)
    converters.save_json(jsonUH, 'TestResults\\unique_headers.json')
    print(f"Unique Headers Number: {len(uniqueHeaders)}")

def get_unnecessary_headers():
    uniqueHeaders = converters.load_pickle(DECISIONS_FOLDER_NAME + 'DecisionHeaders.pickle')
    uniqueHeadersIDs = []
    for h in uniqueHeaders:
        uniqueHeadersIDs.append(h.doc_id)
    keysDownloadedFiles = []
    fileList = os.listdir(DECISIONS_FOLDER_NAME)
    for filepath in fileList:
        filename = os.path.basename(filepath)
        if not filename.endswith('.txt'):
            continue
        keysDownloadedFiles.append(filename.replace('_', '/').replace('.txt', ''))
    unnecessaryFiles = []
    for key in keysDownloadedFiles:
        if key not in uniqueHeadersIDs:
            unnecessaryFiles.append(key)
    with open("TestResults\\unnecessaryFiles.txt", 'wt', encoding='utf-8') as outfile:
        outfile.write('\n'.join(unnecessaryFiles))


def my_collect_headers(pathToFileForSave, pagesNum=None):
    headersOld = ksrf.get_decision_headers(pagesNum)
    converters.save_json(headersOld, pathToFileForSave +'.json')
    headersNew = converters.convert_to_class_format(headersOld, models.DocumentHeader)
    converters.save_pickle(headersNew, pathToFileForSave + '.pickle')
    return headersNew


def saving_all_clean_links(num=None):
    cleanLinks = converters.load_pickle(os.path.join(RESULTS_FOLDER_NAME, 'сleanLinks.pickle'))
    cleanLinksLists = list(cleanLinks[key] for key in cleanLinks if cleanLinks[key])
    cleanLinksList = []
    summ = 0
    for L in cleanLinksLists:
        if not L:
            continue
        summ += len(L)
        cleanLinksList.extend(L)
        if num is not None and num < summ:
            break
    JSONcleanLinks = converters.convert_to_json_serializable_format(cleanLinksList)
    if num is None:
        converters.save_json(JSONcleanLinks, os.path.join(RESULTS_FOLDER_NAME, 'cleanLinks.json'))
    else:
        converters.save_json(JSONcleanLinks, os.path.join(RESULTS_FOLDER_NAME, '\\num_' + str(summ) +'_jsonCleanLinks.json'))

def generate_links(N):
    strings = []
    for i in range(N+1):
        strings.append(f"http://doc.ksrf.ru/decision/KSRFDecision{i}.pdf")
    with open(r"C:\VS Code Projects\pdf_links.txt", 'w') as file:
        file.write('\n'.join(strings))

def prepare_ac_files(pathToACfile, pathToResultFolder=r'ACresult', nameDecHeadersFile='acDecisionHeaders.jsonlines', includeText=False):
    os.makedirs(pathToResultFolder, exist_ok=True)
    with open(pathToACfile, 'r', encoding='utf-8') as file:
        lines = ['spameggs']
        while lines:
            lines = []
            acDeicionsText = ''
            for line in file:
                if '------------------------------------------------------------------' not in line:
                    lines.append(line)
                else:
                    while True:
                        line = file.readline()
                        if 'Название документа' not in line:
                            lines.append(line)
                        else:
                            break
                    break
            acDeicionsText = ''.join(lines)
            if not lines:
                continue
            #titlePart1Pattern=re.compile(r'(?:(?<=Название документа)[\w\W]*?(?=^\S)|\S[\w\W]*?(?=^\S))', re.MULTILINE)
            titlePart1Pattern = re.compile(r'.*по делу.*')
            titlePart2Pattern = re.compile(r'(?<=Требование\:).*')
            textPattern = re.compile(r'(?<=Текст документа)[\w\W]*\S')
            datePattern = re.compile(r'\d\d\.\d\d\.\d{4}')
            numberPattern =re.compile(r'(?<=N).*$')
            with open(rf"{pathToResultFolder}\{nameDecHeadersFile}", 'a', encoding='utf-8') as resultDecFile:
                acd = acDeicionsText
            
                title = titlePart1Pattern.search(acd)[0].strip()
                date = datePattern.search(title)[0].strip()
                text = textPattern.search(acd)[0].strip()
                number = numberPattern.search(title)[0].strip()
                doc_id = f"АС_ТЕСТ/{number}"
                doc_type = supertype = 'АС_ТЕСТ'
                body = {
                    'supertype': supertype,
                    'doc_type': doc_type,
                    'title': title,
                    'release_date': date,
                    'text_source_url': 'null',
                    }
                if includeText:
                    body['text'] = text
                with open(rf"{pathToResultFolder}\{doc_id.replace('/','_')+'.txt'}", 'w', encoding='utf-8') as textFile:
                    textFile.write(text)
                resultDecFile.write(json.dumps({doc_id: body}, ensure_ascii=False)+'\n')

def convert_dict_to_jsonlines_dict(pathToDict, pathToRes):
    with open(pathToDict, 'r', encoding='utf-8') as file:
        jsonText = json.load(file)
    with open(pathToRes, 'a', encoding='utf-8') as file:
        for key in jsonText:
            file.write(json.dumps({key: jsonText[key]}, ensure_ascii=False) + '\n')
            
def convert_dict_with_links_to_jsonlines_dict(pathToDict, pathToRes):
    with open(pathToDict, 'r', encoding='utf-8') as file:
        jsonText = json.load(file)
    with open(pathToRes, 'a', encoding='utf-8') as file:
        for line in jsonText:
            file.write(json.dumps(line, ensure_ascii=False) + '\n')

def read_all_json_lines_and_save(fromPath, toPath):
    with open(toPath, 'a', encoding='utf-8') as file:
        for line in open(fromPath, 'r', encoding='utf-8'):
            jsonText = json.loads(line.strip(), encoding='utf-8')
            file.write(json.dumps(jsonText, ensure_ascii=False) + '\n')

def convert_jsonlines_dict_to_dict(pathToJsonlinesDict, pathToRes):
    resDict = {}
    keys=[]
    for line in open(pathToJsonlinesDict, 'r', encoding='utf-8'):
            slovar = json.loads(line.strip())
            resDict.update(slovar)
    with open(pathToRes, 'w', encoding='utf-8') as file:
        json.dump(resDict, file, ensure_ascii=False)

def convert_dict_dict_to_list_dict(pathToDict, pathToRes):
    with open(pathToDict, 'r', encoding='utf-8') as file:
        jsonText = json.load(file)
    resList = []
    for key in jsonText:
        d = jsonText[key]
        d['doc_id']=key
        resList.append(d)
    with open(pathToRes, 'w', encoding='utf-8') as file:
        json.dump(resList, file, ensure_ascii=False)

def join_files(file1, file2, outputFile):
    with open(outputFile, 'a', encoding='utf-8') as output:
        for line in open(file1, 'r', encoding='utf-8'):
            output.write(line)
        for line in open(file2, 'r', encoding='utf-8'):
            output.write(line)

def delete_duplicate_lines(fileFrom, fileTo):
    with open(fileFrom, 'r', encoding='utf-8') as inF, \
            open(fileTo, 'w', encoding='utf-8') as outF:
        spisok = inF.readlines()
        ss = set(spisok)
        outF.write(''.join(ss))

if __name__ == '__main__':
    delete_duplicate_lines(r'rejected_links.txt',r'WOduplicates_rejected_links.txt')
