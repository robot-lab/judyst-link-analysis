import converters
from web_crawler import ksrf
from api_module import DECISIONS_FOLDER_NAME, PATH_TO_PICKLE_HEADERS
import os
import models
import web_crawler
ALL_CLEAN_LINKS_PATH = 'TestResults\\allCleanLinks.pickle'


def get_only_unique_headers(pathToPickleHeaders=PATH_TO_PICKLE_HEADERS):
    allHeaders = converters.load_pickle(pathToPickleHeaders)
    uniqueHeaders = []
    for key in allHeaders:
        if isinstance(allHeaders[key], models.Header):
            uniqueHeaders.append(allHeaders[key])
    print(f"Number of unique Headers: {len(uniqueHeaders)}")
    converters.save_pickle(uniqueHeaders, 'TestResults\\unique_headers.pickle')
    uniqueHeadersJson = converters.convert_to_json_serializable_format(uniqueHeaders)
    converters.save_json(uniqueHeadersJson, 'TestResults\\unique_headers.json')
    fileList = os.listdir(DECISIONS_FOLDER_NAME)
    keysDownloadedFiles = []
    keysNotDownloadedFiles = []
    for filepath in fileList:
        filename = os.path.basename(filepath)
        if not filename.endswith('.txt'):
            continue
        keysDownloadedFiles.append(filename.replace('_', '/').replace('.txt', ''))
    for h in uniqueHeaders:
        if h.doc_id not in keysDownloadedFiles:
            keysNotDownloadedFiles.append(h.doc_id)
    print(keysNotDownloadedFiles)
    with open("TestResults\\notDownlodedFilesKeys.txt", 'wt', encoding='utf-8') as outfile:
        outfile.write('\n'.join(keysNotDownloadedFiles))

def get_unnecessary_headers():
    uniqueHeaders = converters.load_pickle('TestResults\\unique_headers.pickle')
    uniqueHeadersIDs = []
    for h in uniqueHeaders:
        uniqueHeadersIDs.append(h.doc_id)
    keysDownloadedFiles = []
    fileList = os.listdir(DECISIONS_FOLDER_NAME)
    for filepath in fileList:
        filename = os.path.basename(filepath)
        if not filename.endswith('.txt'):
            continue
        keysDownloadedFiles.append(filename.replace('_', '/').replace('.txt', ''))
    unnecessaryFiles = []
    for key in keysDownloadedFiles:
        if key not in uniqueHeadersIDs:
            unnecessaryFiles.append(key)
    with open("TestResults\\unnecessaryFiles.txt", 'wt', encoding='utf-8') as outfile:
        outfile.write('\n'.join(unnecessaryFiles))


def my_collect_headers(pathToFileForSave, pagesNum=None):
    headersOld = ksrf.get_decision_headers(pagesNum)
    converters.save_json(headersOld, pathToFileForSave +'.json')
    headersNew = converters.convert_to_class_format(headersOld, models.DocumentHeader)
    converters.save_pickle(headersNew, pathToFileForSave + '.pickle')
    return headersNew


def saving_all_clean_links(num=None):
    cleanLinks = converters.load_pickle(ALL_CLEAN_LINKS_PATH)
    cleanLinksLists = list(cleanLinks[key] for key in cleanLinks if cleanLinks[key])
    cleanLinksList = []
    summ = 0
    for L in cleanLinksLists:
        summ += len(L)
        cleanLinksList.extend(L)
        if num is not None and num < summ:
            break
    JSONcleanLinks = converters.convert_to_json_serializable_format(cleanLinksList)
    if num is None:
        converters.save_json(JSONcleanLinks, 'TestResults\\jsonAllCleanLinks.json')
    else:
        converters.save_json(JSONcleanLinks, 'TestResults\\num_' + str(summ) +'_jsonCleanLinks.json')


if __name__ == '__main__':
    saving_all_clean_links()