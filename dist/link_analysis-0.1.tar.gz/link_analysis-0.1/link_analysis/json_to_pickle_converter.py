import json
import pickle
import os
import datetime
import dateutil.parser
import re
from link_analysis.models import Header, DuplicateHeader

DECISIONS_FOLDER_NAME = "Decision files"
HEADERS_FILE_NAME = os.path.join(DECISIONS_FOLDER_NAME, 'DecisionHeaders.json')
PICKLE_HEADERS_FILE_NAME = os.path.join(DECISIONS_FOLDER_NAME,
                                        'DecisionHeaders.pickle')


def convert_headers_from_json_to_pickle():
    with open(HEADERS_FILE_NAME, 'r', encoding='UTF-8') as headersJsonFile:
        decisionsHeadersOldFormat = json.loads(headersJsonFile.read())
    decisionsHeadersNewFormat = {}
    for key in decisionsHeadersOldFormat:
        docID = 'КСРФ/' + key
        spam = re.search(r"(?:[А-Яа-я][-А-Яа-я]*(?=-\d)|"
                         r"[А-Яа-я][-А-Яа-я]*(?=/)|[А-Яа-я][-А-Яа-я]*(?=\.)|"
                         r"[А-Яа-я][-А-Яа-я]*(?=\d))", key)[0]
        docType = "КСРФ/" + spam
        if 'not unique' not in decisionsHeadersOldFormat[key]:
            title = decisionsHeadersOldFormat[key]['title']
            date = dateutil.parser.parse(
                decisionsHeadersOldFormat[key]['date'],
                dayfirst=True).date()
            sourceUrl = decisionsHeadersOldFormat[key]['url']
            if 'path to text file' in decisionsHeadersOldFormat[key]:
                textLocation = re.sub(
                    r"\\", "\\КСРФ_",
                    decisionsHeadersOldFormat[key]['path to text file'])
            else:
                textLocation = None
            decisionsHeadersNewFormat[docID] = Header(
                docID, docType, title, date, sourceUrl, textLocation)
        else:
            duplicateHeader = DuplicateHeader(docID)
            for dh in decisionsHeadersOldFormat[key][1]:
                title = dh['title']
                date = dateutil.parser.parse(dh['date'], dayfirst=True).date()
                sourceUrl = dh['url']
                if 'path to text file' in dh:
                    textLocation = re.sub(r"\\", "\\КСРФ_",
                                          dh['path to text file'])
                else:
                    textLocation = None
                duplicateHeader.append(docType, title, date,
                                       sourceUrl, textLocation)
            decisionsHeadersNewFormat[docID] = duplicateHeader
    return decisionsHeadersNewFormat


def save_pickle(headersDict, pathToFile=PICKLE_HEADERS_FILE_NAME):
    try:
        os.makedirs(os.path.dirname(pathToFile), exist_ok=True)
        with open(pathToFile, 'wb') as pickleFile:
            pickle.dump(headersDict, pickleFile)
    except OSError:
        return False
    return True


def load_pickle(pathToFile=PICKLE_HEADERS_FILE_NAME):
    try:
        with open(pathToFile, 'rb') as pickleFile:
            data = pickle.load(pickleFile, encoding='UTF-8')
    except OSError:
        return None
    return data


if __name__ == '__main__':
    # CheckLoadDecisionsHeadersNewFormat = load_pickle()
    # for key in CheckLoadDecisionsHeadersNewFormat:
    #     print(CheckLoadDecisionsHeadersNewFormat[key])
    #     break
    a = convert_headers_from_json_to_pickle()
    save_pickle(a)
    print("press any key...")
